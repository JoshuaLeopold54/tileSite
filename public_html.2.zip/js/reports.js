const JOBS_ENDPOINT = '/api/jobs.php';
const USERS_ENDPOINT = '/api/users.php';
const numberFormat = new Intl.NumberFormat('en-US');
const currencyFormat = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0
});

let jobs = [];
let userLookup = new Map();
const loadIssues = [];

document.addEventListener('DOMContentLoaded', () => {
  initReports().catch(err => console.error('Failed to initialise reports', err));
});

async function initReports() {
  await Promise.all([loadJobs(), loadUsers()]);
  showLoadIssues();
  updateTimestamp();
  renderSummary();
  renderStatusBreakdown();
  renderPipelineTables();
  renderUpcomingKickoffs();
  renderTopGCs();
  renderTeamWorkload();
}

async function loadJobs() {
  try {
    const response = await fetch(JOBS_ENDPOINT);
    if (response.status === 401) {
      window.location.href = '/login.php';
      return;
    }
    if (!response.ok) throw new Error(`Unexpected ${response.status}`);
    const data = await response.json();
    jobs = (Array.isArray(data) ? data : []).map(job => ({
      ...job,
      materials: normaliseMaterials(job.materials)
    }));
  } catch (error) {
    console.error('Unable to load jobs for reports:', error);
    jobs = [];
    loadIssues.push('We were unable to load job data. Try refreshing the page.');
  }
}

async function loadUsers() {
  try {
    const response = await fetch(USERS_ENDPOINT);
    if (response.status === 401) return; // handled in job load
    if (!response.ok) throw new Error(`Unexpected ${response.status}`);
    const data = await response.json();
    const list = Array.isArray(data) ? data : [];
    userLookup = new Map(
      list
        .filter(user => user && (user.id ?? user.user_id) !== undefined)
        .map(user => {
          const id = String(user.id ?? user.user_id);
          const name = formatUserName(user);
          return [id, { ...user, label: name }];
        })
    );
  } catch (error) {
    console.error('Unable to load users for reports:', error);
    userLookup = new Map();
    loadIssues.push('Team assignments could not be loaded. Workload by team may be incomplete.');
  }
}

function normaliseMaterials(raw) {
  if (Array.isArray(raw)) return raw.filter(isMaterialRecord);
  try {
    const parsed = JSON.parse(raw ?? '[]');
    return Array.isArray(parsed) ? parsed.filter(isMaterialRecord) : [];
  } catch (err) {
    return [];
  }
}

function isMaterialRecord(item) {
  return typeof item === 'object' && item !== null && 'qty' in item && 'unitPrice' in item;
}

function updateTimestamp() {
  const tsEl = document.getElementById('reportsTimestamp');
  if (!tsEl) return;
  const now = new Date();
  tsEl.textContent = `Updated ${now.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  })}`;
}

function renderSummary() {
  const totalJobs = jobs.length;
  const biddingJobs = jobs.filter(job => includesStatus(job.status, 'bidding')).length;
  const materialsJobs = jobs.filter(job => includesStatus(job.status, 'material')).length;
  const totalSqft = jobs.reduce((sum, job) => sum + getSqft(job), 0);
  const materialCost = jobs.reduce((sum, job) => sum + calculateMaterialCost(job.materials), 0);
  const avgSqft = totalJobs ? totalSqft / totalJobs : 0;

  setText('metric-total-jobs', numberFormat.format(totalJobs));
  setText('metric-bidding-jobs', numberFormat.format(biddingJobs));
  setText('metric-material-jobs', numberFormat.format(materialsJobs));
  setText('metric-total-sqft', numberFormat.format(Math.round(totalSqft)));
  setText('metric-material-cost', currencyFormat.format(materialCost));

  const biddingShare = totalJobs ? Math.round((biddingJobs / totalJobs) * 100) : 0;
  const materialShare = totalJobs ? Math.round((materialsJobs / totalJobs) * 100) : 0;

  setText('metric-bidding-share', totalJobs ? `${biddingShare}% of active work` : '');
  setText('metric-material-share', totalJobs ? `${materialShare}% of active work` : '');
  setText('metric-average-sqft', totalJobs ? `Avg ${Math.round(avgSqft).toLocaleString()} sq ft per job` : '');
  setText('metric-material-cost-note', materialCost ? 'Based on listed material quantities × unit price' : '');
}

function renderStatusBreakdown() {
  const tbody = document.getElementById('statusBreakdownBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!jobs.length) {
    tbody.appendChild(createEmptyRow(4));
    return;
  }

  const statusMap = new Map();
  for (const job of jobs) {
    const status = (job.status || 'Unspecified').trim() || 'Unspecified';
    if (!statusMap.has(status)) {
      statusMap.set(status, { count: 0, sqft: 0 });
    }
    const entry = statusMap.get(status);
    entry.count += 1;
    entry.sqft += getSqft(job);
  }

  const totalJobs = jobs.length;
  const sorted = Array.from(statusMap.entries()).sort((a, b) => b[1].count - a[1].count);
  for (const [status, { count, sqft }] of sorted) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <th scope="row">${escapeHtml(status)}</th>
      <td>${numberFormat.format(count)}</td>
      <td>${((count / totalJobs) * 100).toFixed(1)}%</td>
      <td>${numberFormat.format(Math.round(sqft))}</td>
    `;
    tbody.appendChild(row);
  }
}

function renderPipelineTables() {
  renderJobTable({
    rows: jobs.filter(job => includesStatus(job.status, 'bidding')),
    containerId: 'biddingTableBody',
    emptyCopy: 'No jobs currently in bidding.',
    mode: 'bidding'
  });
  renderJobTable({
    rows: jobs.filter(job => includesStatus(job.status, 'material')),
    containerId: 'materialsTableBody',
    emptyCopy: 'No jobs awaiting materials.',
    mode: 'materials'
  });
}

function renderJobTable({ rows, containerId, emptyCopy, mode }) {
  const tbody = document.getElementById(containerId);
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!rows.length) {
    tbody.appendChild(createEmptyRow(tbody.parentElement?.querySelectorAll('th').length || 1, emptyCopy));
    return;
  }

  const sorted = rows
    .slice()
    .sort((a, b) => {
      const dateResult = compareDates(getPipelineDateValue(a, mode), getPipelineDateValue(b, mode));
      if (dateResult !== 0) return dateResult;
      return (a.name || '').localeCompare(b.name || '');
    });
  for (const job of sorted) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <th scope="row">${escapeHtml(job.name || 'Untitled Job')}</th>
      <td>${escapeHtml(job.gc || '—')}</td>
      <td>${formatDate(getPipelineDateValue(job, mode))}</td>
      <td>${numberFormat.format(Math.round(getSqft(job)))}</td>
      <td>${escapeHtml(getAssigneeLabel(job))}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderUpcomingKickoffs() {
  const list = document.getElementById('upcomingList');
  if (!list) return;
  list.innerHTML = '';

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const upcoming = jobs
    .map(job => ({ ...job, dateObj: parseDate(job.date) }))
    .filter(job => job.dateObj && job.dateObj >= today)
    .sort((a, b) => a.dateObj - b.dateObj)
    .slice(0, 5);

  if (!upcoming.length) {
    list.appendChild(createEmptyItem('No scheduled start dates available.'));
    return;
  }

  for (const job of upcoming) {
    const li = document.createElement('li');
    li.innerHTML = `
      <span class="timeline-date">${formatDate(job.dateObj ?? job.date)}</span>
      <div>
        <strong>${escapeHtml(job.name || 'Untitled Job')}</strong>
        <p>${escapeHtml(job.status || 'Status TBD')} • ${escapeHtml(job.gc || 'GC TBD')} • ${escapeHtml(getAssigneeLabel(job))}</p>
      </div>
    `;
    list.appendChild(li);
  }
}

function renderTopGCs() {
  const tbody = document.getElementById('gcTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!jobs.length) {
    tbody.appendChild(createEmptyRow(3));
    return;
  }

  const gcMap = new Map();
  for (const job of jobs) {
    const gc = (job.gc || 'Unassigned').trim() || 'Unassigned';
    if (!gcMap.has(gc)) {
      gcMap.set(gc, { count: 0, sqft: 0 });
    }
    const entry = gcMap.get(gc);
    entry.count += 1;
    entry.sqft += getSqft(job);
  }

  const sorted = Array.from(gcMap.entries())
    .sort((a, b) => {
      if (b[1].count !== a[1].count) return b[1].count - a[1].count;
      return b[1].sqft - a[1].sqft;
    })
    .slice(0, 6);

  for (const [gc, { count, sqft }] of sorted) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <th scope="row">${escapeHtml(gc)}</th>
      <td>${numberFormat.format(count)}</td>
      <td>${numberFormat.format(Math.round(sqft))}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderTeamWorkload() {
  const tbody = document.getElementById('teamTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!jobs.length) {
    tbody.appendChild(createEmptyRow(3));
    return;
  }

  const teamMap = new Map();
  for (const job of jobs) {
    const key = String(job.assignee ?? 'unassigned');
    if (!teamMap.has(key)) {
      teamMap.set(key, { label: getAssigneeLabel(job), count: 0, sqft: 0 });
    }
    const entry = teamMap.get(key);
    entry.count += 1;
    entry.sqft += getSqft(job);
  }

  const sorted = Array.from(teamMap.values())
    .sort((a, b) => {
      if (b.count !== a.count) return b.count - a.count;
      return b.sqft - a.sqft;
    });

  for (const { label, count, sqft } of sorted) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <th scope="row">${escapeHtml(label || 'Unassigned')}</th>
      <td>${numberFormat.format(count)}</td>
      <td>${numberFormat.format(Math.round(sqft))}</td>
    `;
    tbody.appendChild(tr);
  }
}

function includesStatus(value, keyword) {
  return typeof value === 'string' && value.toLowerCase().includes(keyword);
}

function getSqft(job) {
  const total = Number(job.sqftTotal);
  if (!Number.isNaN(total) && total > 0) return total;
  const walls = Number(job.sqftWalls) || 0;
  const floors = Number(job.sqftFloors) || 0;
  return walls + floors;
}

function calculateMaterialCost(materials = []) {
  return materials.reduce((sum, item) => {
    const qty = Number(item.qty) || 0;
    const price = Number(item.unitPrice) || 0;
    return sum + qty * price;
  }, 0);
}

function createEmptyRow(colspan, message = 'No data to display.') {
  const tr = document.createElement('tr');
  const td = document.createElement('td');
  td.colSpan = colspan;
  td.className = 'empty-state';
  td.textContent = message;
  tr.appendChild(td);
  return tr;
}

function createEmptyItem(message) {
  const li = document.createElement('li');
  li.className = 'empty-state';
  li.textContent = message;
  return li;
}

function formatDate(input) {
  const date = parseDate(input);
  if (!date) return '—';
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function getPipelineDateValue(job, mode) {
  const candidateFields = mode === 'bidding'
    ? ['bidDue', 'bid_due', 'proposalDue', 'proposal_due']
    : ['neededBy', 'needed_by', 'materialsDate', 'materials_date'];
  for (const field of candidateFields) {
    if (job[field]) return job[field];
  }
  return job.date;
}

function compareDates(a, b) {
  const dateA = parseDate(a);
  const dateB = parseDate(b);
  if (dateA && dateB) return dateA - dateB;
  if (dateA) return -1;
  if (dateB) return 1;
  return 0;
}

function parseDate(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = value || '–';
}

function escapeHtml(value) {
  return (value ?? '').toString().replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);
}

function getAssigneeLabel(job) {
  const id = job.assignee ?? '';
  if (id === '' || id === null) return 'Unassigned';
  const lookup = userLookup.get(String(id));
  return lookup?.label || `User #${id}`;
}

function formatUserName(user) {
  const parts = [user.first_name, user.last_name].filter(Boolean);
  if (parts.length) return parts.join(' ');
  return user.username || user.email || `User #${user.id ?? user.user_id}`;
}

function showLoadIssues() {
  const alert = document.getElementById('reportsError');
  if (!alert) return;
  if (!loadIssues.length) {
    alert.hidden = true;
    alert.textContent = '';
    return;
  }
  alert.hidden = false;
  alert.textContent = loadIssues.join(' ');
}