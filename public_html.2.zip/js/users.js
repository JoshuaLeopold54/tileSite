console.log('🛠 users.js loaded');

document.addEventListener('DOMContentLoaded', init);

const API = '/api/users.php';
let users = [];
let editingId = null;

const form = document.getElementById('userForm');
const tbl = document.querySelector('#usersTable tbody');
const submitBtn = form.querySelector('button[type="submit"]');

async function init() {
  await load();
  form.addEventListener('submit', onSave);
}

async function load() {
  const res = await fetch(API);
  if (!res.ok) {
    const txt = await res.text();
    console.error('Error loading users:', res.status, txt);
    return alert('Error loading users: ' + txt);
  }
  users = await res.json();
  render();
}

function render() {
  tbl.innerHTML = '';
  users.forEach(u => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><button data-id="${u.id}" class="edit-btn">✎</button></td>
      <td>${u.id}</td>
      <td>${u.username || ''}</td>
      <td>${u.first_name || ''} ${u.last_name || ''}</td>
      <td>${u.email || ''}</td>
      <td>${u.role || ''}</td>
      <td><button data-id="${u.id}" class="delete-btn">🗑</button></td>
    `;
    tbl.appendChild(tr);
  });

  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.onclick = () => {
      const u = users.find(u => u.id == btn.dataset.id);
      if (u) {
        populate(u);
        submitBtn.textContent = '💾 Save User';
        submitBtn.classList.add('edit-mode');
      }
    };
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Delete this user? This cannot be undone.')) return;
      const res = await fetch(`${API}?id=${btn.dataset.id}`, { method: 'DELETE' });
      if (!res.ok) {
        const err = await res.text();
        console.error('Delete failed:', res.status, err);
        return alert('Error deleting user: ' + err);
      }
      await load();
    };
  });
}

function populate(u) {
  editingId = u.id;
  form.username.value    = u.username || '';
  form.password.required = false;
  form.password.value    = '';
  form.first_name.value  = u.first_name || '';
  form.last_name.value   = u.last_name || '';
  form.email.value       = u.email || '';
  if (form.phone)      form.phone.value      = u.phone      || '';
  if (form.position)   form.position.value   = u.position   || '';
  if (form.department) form.department.value = u.department || '';
  form.role.value       = u.role || 'viewer';
  if (form.avatar_url) form.avatar_url.value = u.avatar_url || '';
}

async function onSave(e) {
  e.preventDefault();
  const fd = new FormData(form);
  const obj = {};
  fd.forEach((v, k) => obj[k] = v);

  const opts = {
    method: editingId ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(editingId ? { ...obj, id: editingId } : obj)
  };

  const res = await fetch(API, opts);
  if (!res.ok) {
    let err;
    try { err = await res.json(); }
    catch { err = { message: await res.text() }; }
    console.error('🛑 Save failed:', err);
    alert('Save failed: ' + (err.message || err.error || JSON.stringify(err)));
    return;
  }

  // Reset state after success
  editingId = null;
  form.reset();
  submitBtn.textContent = '➕ Create New User';
  submitBtn.classList.remove('edit-mode');

  await load();
}
