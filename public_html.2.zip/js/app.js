// js/app.js

document.addEventListener('DOMContentLoaded', init);

const API = '/api/jobs.php';
const materialTypes = [
  'Ceramic Tile',
  'Porcelain Tile',
  'Stone Tile',
  'Large Format Tile',
  'Metal',
  'Waterproofing',
  'Setting Material',
  'Misc.'
];
const statuses = [
  'Take-off',
  'Take-off (finished)',
  'Bidding',
  'Bidding (accepted)',
  'Bidding (declined)',
  'Materials',
  'On-going'
];
let jobs = [];
let filteredJobs = [];
let editingId = null;
let currentSort = { field: null, asc: true };
let currentJobId = null;

let users = [];

const form = document.getElementById('jobForm');
const jobNameInput = document.getElementById('jobName');
const gcNameInput = document.getElementById('gcName');
const dateInput = document.getElementById('startDate');
const typeCheckboxes = () => Array.from(document.querySelectorAll('input[name="type"]'));
const submitBtn = form?.querySelector('button[type="submit"]');
const tbody = document.querySelector('#jobsTable tbody');

const panel = document.getElementById('detailsPanel');
const closeBtn = document.getElementById('closeDetails');
const saveBtn = document.getElementById('det-save');
const overlay = document.getElementById('detailsOverlay');

const isViewer = window.USER_ROLE === 'viewer';

async function init() {
    await Promise.all([loadJobs(), loadUsers()]);
  renderTable();
  bindForm();
   applyViewerMode();
}

function applyViewerMode(scope = document) {
  if (!isViewer) return;
  
  if (scope === document && form) {
    form.style.display = 'none';
    form.setAttribute('aria-hidden', 'true');
  }

  // disable overlay fields if viewer
scope.querySelectorAll('.status-select').forEach(sel => {
    sel.disabled = true;
    sel.setAttribute('aria-disabled', 'true');
  });

  scope.querySelectorAll('.edit-btn, .delete-btn, .save-details-btn, .add-material-btn, .remove-material-btn').forEach(btn => {
    btn.style.display = 'none';
    if (btn.tagName === 'BUTTON') btn.disabled = true;
    btn.setAttribute('aria-hidden', 'true');
  });

  scope.querySelectorAll('.details input, .details select, .details textarea, .details-panel input, .details-panel select, .details-panel textarea').forEach(el => {
    if (!el.hasAttribute('readonly')) el.disabled = true;
  });

  const uploadForm = document.getElementById('fileUploadForm');
  uploadForm?.querySelectorAll('input, button').forEach(el => {
    el.disabled = true;
    el.setAttribute('aria-disabled', 'true');
  });

  const overlayAddBtn = document.getElementById('det-addMat');
  if (overlayAddBtn) overlayAddBtn.style.display = 'none';
  if (saveBtn) saveBtn.style.display = 'none';
}

async function loadUsers() {
  try {
    const res = await fetch('/api/users.php');
    if (!res.ok) throw new Error(String(res.status));
    users = await res.json();
  } catch (err) {
    console.warn('loadUsers failed:', err);
    users = [];
  }
}

async function loadJobs() {
  try {
    const res = await fetch(API);
    if (res.status === 401) {
      window.location.href = '/login.php';
      return;
    }
    if (!res.ok) {
      console.error(`Unexpected ${res.status} from ${API}:`, await res.text());
      jobs = [];
      return;
    }
    const data = await res.json().catch(() => []);
 jobs = data.map(job => {
      let mats = [];
      try {
        mats = Array.isArray(job.materials)
          ? job.materials
          : JSON.parse(job.materials || '[]');
      } catch {
        mats = [];
      }
      mats = mats.filter(m => typeof m === 'object' && m !== null);
      return { ...job, materials: mats };
    });
  } catch (err) {
    console.error('Network error in loadJobs():', err);
    jobs = [];
  }
}

async function saveJobs() {
if (isViewer) return;
  try {
    await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(jobs)
    });
  } catch (err) {
    console.error('saveJobs error', err);
  }
}

// showConfirm(message) ⇒ Promise<boolean>
function showConfirm(message) {
  return new Promise(resolve => {
    const modal  = document.getElementById('confirmModal');
    const msgEl  = document.getElementById('confirmMessage');
    const btnOk  = document.getElementById('confirmOk');
    const btnNo  = document.getElementById('confirmCancel');

    msgEl.textContent = message;
    modal.classList.remove('hidden');

    function cleanup(answer) {
      modal.classList.add('hidden');
      btnOk.removeEventListener('click', onOk);
      btnNo.removeEventListener('click', onNo);
      resolve(answer);
    }
    function onOk() { cleanup(true); }
    function onNo() { cleanup(false); }

    btnOk.addEventListener('click', onOk);
    btnNo.addEventListener('click', onNo);
  });
}

function renderTable(data = jobs) {
  tbody.innerHTML = '';
 const columnLabels = {
    name: 'Job Name',
    gc: 'GC Name',
    date: 'Start Date',
    type: 'Type'
  };

    // ── MAIN ROW ──
  if (!Array.isArray(data) || data.length === 0) {
    const emptyRow = document.createElement('tr');
    const emptyCell = document.createElement('td');
    emptyCell.colSpan = 8;
    emptyCell.classList.add('empty-state');
    emptyCell.textContent = 'No jobs found. Try adjusting your search or add a new job to get started.';
    emptyRow.appendChild(emptyCell);
    tbody.appendChild(emptyRow);
    bindSorting();
    applyViewerMode();
    return;
  }

    // ✎ Edit button
data.forEach(job => {
    const row = document.createElement('tr');

    const editCell = document.createElement('td');
    editCell.classList.add('action-cell');
    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.classList.add('btn', 'btn-secondary', 'edit-btn');
    editBtn.dataset.id = job.id;
    editBtn.textContent = '✎';
    editBtn.title = `Edit ${job.name}`;
    editBtn.setAttribute('aria-label', `Edit job ${job.name}`);
    editCell.appendChild(editBtn);
    row.appendChild(editCell);

    ['name', 'gc', 'date', 'type'].forEach(field => {
      const cell = document.createElement('td');
      cell.dataset.label = columnLabels[field];
      cell.textContent = job[field] ?? '';
      row.appendChild(cell);
    });

    // Status <select>
  const statusCell = document.createElement('td');
    statusCell.dataset.label = 'Status';
    const status = job.status && statuses.includes(job.status) ? job.status : statuses[0];
    job.status = status;
    const slug = status.toLowerCase().replace(/[()]/g, '').replace(/\s+/g, '-');
    const select = document.createElement('select');
    select.classList.add('status-select', `status-${slug}`);
    select.dataset.id = job.id;
    statuses.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s;
      opt.textContent = s;
      if (s === status) opt.selected = true;
      select.appendChild(opt);
    });
    statusCell.appendChild(select);
    row.appendChild(statusCell);

    const moreCell = document.createElement('td');
    moreCell.classList.add('action-cell');
    const moreBtn = document.createElement('button');
    moreBtn.type = 'button';
    moreBtn.classList.add('btn','btn-secondary','more-btn','action-btn');
    moreBtn.dataset.id = job.id;
    moreBtn.dataset.jobName = job.name;
    moreBtn.textContent = '⤵';
    
    moreBtn.title = `View details for ${job.name}`;
    moreBtn.setAttribute('aria-label', `View details for job ${job.name}`);
    moreBtn.setAttribute('aria-expanded', 'false');
    moreCell.appendChild(moreBtn);
    row.appendChild(moreCell);

    const deleteCell = document.createElement('td');
    deleteCell.classList.add('action-cell');
    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.classList.add('btn','btn-danger','delete-btn','action-btn');
    delBtn.dataset.id = job.id;
    delBtn.textContent = '🗑';
    delBtn.title = `Delete ${job.name}`;
    delBtn.setAttribute('aria-label', `Delete job ${job.name}`);
    deleteCell.appendChild(delBtn);
    row.appendChild(deleteCell);
    
    tbody.appendChild(row);

    const detailsRow = document.createElement('tr');
    detailsRow.id = `details-${job.id}`;
    detailsRow.classList.add('details-row');
    detailsRow.style.display = 'none';

    const detailsCell = document.createElement('td');
    detailsCell.colSpan = 8;
    detailsCell.classList.add('action-cell');
    const detailsWrapper = document.createElement('div');
    detailsWrapper.classList.add('details');

    // --- Materials Section ---
    const materialsHeading = document.createElement('h4');
    materialsHeading.textContent = 'Materials';
    detailsWrapper.appendChild(materialsHeading);


    const matTable = document.createElement('table');
    matTable.classList.add('materials-table');
    const matThead = document.createElement('thead');
    const matHeadRow = document.createElement('tr');
    ['Type','Name','Qty','Unit Price','Total Cost','Status',''].forEach(txt => {
      const th = document.createElement('th');
      th.textContent = txt;
      matHeadRow.appendChild(th);
    });
    matThead.appendChild(matHeadRow);
    matTable.appendChild(matThead);
    // Body
    const matTbody = document.createElement('tbody');
    job.materials.forEach((m, index) => {
      const matRow = buildMaterialRow(m, index);
      matTbody.appendChild(matRow);
    });
    matTable.appendChild(matTbody);
    detailsWrapper.appendChild(matTable);

    // + Add Material
    const addMatBtn = document.createElement('button');
    addMatBtn.type = 'button';
    addMatBtn.classList.add('btn', 'btn-secondary', 'add-material-btn');
    addMatBtn.dataset.id = job.id;
    addMatBtn.textContent = '+ Add Material';
    detailsWrapper.appendChild(addMatBtn);

    const sqftHeading = document.createElement('h4');
    sqftHeading.textContent = 'Square Footage';
    detailsWrapper.appendChild(sqftHeading);

    const sqftDiv = document.createElement('div');
    sqftDiv.classList.add('sqft-row');
     [['Walls', job.sqftWalls], ['Floors', job.sqftFloors], ['Total', job.sqftTotal]].forEach(([label, value]) => {
      const lbl = document.createElement('label');
      lbl.textContent = `${label}: `;
      const input = document.createElement('input');
      input.dataset.field =
        label === 'Total' ? 'sqftTotal' : label === 'Walls' ? 'sqftWalls' : 'sqftFloors';
      input.type = 'number';
      input.min = 0;
      if (label === 'Total') input.readOnly = true;
      input.value = value ?? 0;
      lbl.appendChild(input);
      sqftDiv.appendChild(lbl);
    });
    detailsWrapper.appendChild(sqftDiv);

    const saveDetailsBtn = document.createElement('button');
    saveDetailsBtn.type = 'button';
    saveDetailsBtn.classList.add('btn', 'btn-primary', 'save-details-btn');
    saveDetailsBtn.dataset.id = job.id;
    saveDetailsBtn.textContent = 'Save Details';
    detailsWrapper.appendChild(saveDetailsBtn);

    detailsCell.appendChild(detailsWrapper);
    detailsRow.appendChild(detailsCell);
    tbody.appendChild(detailsRow);
    
  });

  bindSorting();
  bindRowButtons();
  applyViewerMode();
}

function buildMaterialRow(material = {}, index = 0) {
  const row = document.createElement('tr');
  row.dataset.index = index;

  const typeCell = document.createElement('td');
  const typeSelect = document.createElement('select');
  typeSelect.dataset.field = 'type';
  materialTypes.forEach(type => {
    const option = document.createElement('option');
    option.value = type;
    option.textContent = type;
    if (type === material.type) option.selected = true;
    typeSelect.appendChild(option);
  });
  typeCell.appendChild(typeSelect);
  row.appendChild(typeCell);

  [
    ['name', material.name ?? '', 'text', false],
    ['qty', material.qty ?? 0, 'number', false],
    ['unitPrice', material.unitPrice ?? 0, 'number', false],
    ['totalCost', material.totalCost ?? 0, 'number', true]
  ].forEach(([field, value, type, readOnly]) => {
    const cell = document.createElement('td');
    const input = document.createElement('input');
    input.dataset.field = field;
    input.type = type;
    if (type === 'number') {
      input.min = 0;
      if (field === 'unitPrice') input.step = '0.01';
    }
    if (field === 'totalCost') {
      input.value = Number(value || 0).toFixed(2);
    } else {
      input.value = type === 'number' ? Number(value || 0) : value;
    }
    if (readOnly) input.readOnly = true;
    cell.appendChild(input);
    row.appendChild(cell);
  });

  const statusCell = document.createElement('td');
  const statusSelect = document.createElement('select');
  statusSelect.dataset.field = 'matStatus';
  ['Pending', 'Ordered', 'Delivered'].forEach(status => {
    const opt = document.createElement('option');
    opt.value = status;
    opt.textContent = status;
    if (status === material.matStatus) opt.selected = true;
    statusSelect.appendChild(opt);
  });
  statusCell.appendChild(statusSelect);
  row.appendChild(statusCell);

  const removeCell = document.createElement('td');
  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.classList.add('btn', 'btn-danger', 'btn-sm', 'remove-material-btn');
  removeBtn.textContent = 'Remove';
  removeCell.appendChild(removeBtn);
  row.appendChild(removeCell);

  bindMaterialRow(row);
  return row;
}
document.getElementById('jobSearch')?.addEventListener('input', e => {
  const q = e.target.value.toLowerCase();
  filteredJobs = jobs.filter(j =>
    j.name.toLowerCase().includes(q) ||
    j.gc.toLowerCase().includes(q) ||
    j.type.toLowerCase().includes(q)
  );
  renderTable(filteredJobs);
});
function bindSorting() {
  document.querySelectorAll('#jobsTable thead th.sortable')
    .forEach(th => {
      th.onclick = () => {
        const field = th.dataset.sort;
        if (currentSort.field === field) currentSort.asc = !currentSort.asc;
        else {
          currentSort.field = field;
          currentSort.asc = true;
        }
        document.querySelectorAll('th.sortable').forEach(h => h.classList.remove('asc','desc'));
        th.classList.add(currentSort.asc ? 'asc' : 'desc');
        jobs.sort((a,b) => {
          let vA = a[field], vB = b[field];
          if (field === 'date') {
            vA = new Date(vA); vB = new Date(vB);
            return currentSort.asc ? vA - vB : vB - vA;
          }
          if (typeof vA === 'number' && typeof vB === 'number') {
            return currentSort.asc ? vA - vB : vB - vA;
          }
          return currentSort.asc
            ? String(vA).localeCompare(String(vB))
            : String(vB).localeCompare(String(vA));
        });
        renderTable();
      };
    });
}

function populateDetailsPanel(job) {
    if (!panel || !overlay) return;
  currentJobId = job.id;
  const detailsDiv = document.createElement('div');
   document.getElementById('det-name').textContent = job.name ?? '';
  document.getElementById('det-gc').textContent = job.gc ?? '';
  document.getElementById('det-date').textContent = job.date ?? '';
  document.getElementById('det-type').textContent = job.type ?? '';

  const matBody = document.getElementById('det-mats');
  matBody.innerHTML = '';
  if (Array.isArray(job.materials) && job.materials.length) {
    job.materials.forEach((material, index) => {
      matBody.appendChild(buildMaterialRow(material, index));
    });
  } else {
    addEmptyMaterialRow(matBody);
  }

  const wallsInput = document.getElementById('det-walls');
  const floorsInput = document.getElementById('det-floors');
  const totalInput = document.getElementById('det-total');
  wallsInput.value = job.sqftWalls ?? 0;
  floorsInput.value = job.sqftFloors ?? 0;
  totalInput.value = job.sqftTotal ?? 0;
  [wallsInput, floorsInput].forEach(inp => {
    inp.oninput = () => {
      totalInput.value = (Number(wallsInput.value) || 0) + (Number(floorsInput.value) || 0);
    };
  });

 const assigneeSelect = document.getElementById('det-assignee');
  const options = ['<option value="">— Unassigned —</option>'];
  users
    .filter(u => u && u.id !== undefined)
    .forEach(u => {
      const selected = String(u.id) === String(job.assignee || '');
      const label = `${u.first_name ?? ''} ${u.last_name ?? ''}`.trim();
      options.push(`<option value="${u.id}" ${selected ? 'selected' : ''}>${label || 'Unnamed User'}</option>`);
    });
  assigneeSelect.innerHTML = options.join('');

  document.getElementById('det-contact').value = job.contact || '';
  document.getElementById('det-notes').value = job.notes || '';

  const previewEl = document.getElementById('uploadedPreview');
  if (previewEl) {
    previewEl.innerHTML = '';
    const path = job.file_path;
    if (path) {
      const normalized = path.startsWith('/') ? path : `/uploads/job_files/${path}`;
      const lower = path.toLowerCase();
      if (lower.endsWith('.pdf')) {
        const encoded = encodeURIComponent(normalized);
        previewEl.innerHTML = `<iframe src="/pdfjs/viewer.html?file=${encoded}" width="100%" height="300" title="Preview of uploaded PDF"></iframe>`;
      } else if (/(jpe?g|png|gif|webp|svg)$/i.test(lower)) {
        previewEl.innerHTML = `<img src="${normalized}" alt="Uploaded file preview" style="max-width:200px;margin-top:10px;">`;
      } else {
        previewEl.innerHTML = `<a href="${normalized}" target="_blank" rel="noopener">Download uploaded file</a>`;
      }
    }
  }

  applyViewerMode(panel);
  overlay.classList.add('visible');
  panel.classList.remove('hidden');
  panel.classList.add('visible');
}

function bindMaterialRow(row) {
  const removeBtn = row.querySelector('.remove-material-btn');
  if (removeBtn) removeBtn.addEventListener('click', () => row.remove());

  const qtyInp  = row.querySelector('input[data-field="qty"]');
  const upInp   = row.querySelector('input[data-field="unitPrice"]');
  const costInp = row.querySelector('input[data-field="totalCost"]');
  [qtyInp, upInp].forEach(inp => {
    if (!inp) return;
    inp.addEventListener('input', () => {
      const q = Number(qtyInp.value)  || 0;
      const u = Number(upInp.value)   || 0;
      costInp.value = (q * u).toFixed(2);
    });
  });
}

function addEmptyMaterialRow(tbodyEl) {
  const row = buildMaterialRow({
    type: materialTypes[0],
    name: '',
    qty: 0,
    unitPrice: 0,
    totalCost: 0,
    matStatus: 'Pending'
  });
  tbodyEl.appendChild(row);
}

function enterEditMode(e) {
  const id = Number(e.currentTarget.dataset.id);
  const job = jobs.find(j => j.id === id);
  if (!job) return;
  jobNameInput.value   = job.name;
  gcNameInput.value    = job.gc;
  dateInput.value      = job.date;
  typeCheckboxes().forEach(cb => {
    cb.checked = job.type.split(', ').includes(cb.value);
  });
  editingId = id;
  submitBtn.textContent = 'Update Job';
  form.scrollIntoView({ behavior: 'smooth' });
}

function bindRowButtons() {
  // Status changes
  document.querySelectorAll('.status-select').forEach(sel => {
    sel.addEventListener('change', async () => {
      const id  = Number(sel.dataset.id);
      const job = jobs.find(j => j.id === id);
      job.status = sel.value;
      const slug = sel.value.toLowerCase().replace(/[()]/g, '').replace(/\s+/g, '-');
      sel.className = `status-select status-${slug}`;
      await saveJobs();
    });
  });

  // Toggle details panel
  document.querySelectorAll('.more-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.id);
      const job = jobs.find(j => j.id === id);
      if (!job) return;

      const detailRow = document.getElementById(`details-${id}`);
      const isOpen = detailRow && detailRow.style.display !== 'none';

      document.querySelectorAll('.details-row').forEach(row => (row.style.display = 'none'));
      document.querySelectorAll('.more-btn').forEach(other => {
        const jobName = other.dataset.jobName || '';
        other.setAttribute('aria-expanded', 'false');
        if (jobName) {
          other.setAttribute('aria-label', `View details for job ${jobName}`);
          other.title = `View details for ${jobName}`;
        } else {
          other.setAttribute('aria-label', 'View job details');
          other.removeAttribute('title');
        }
      });

      if (isOpen) {
        closeOverlay();
        return;
      }

      if (detailRow) detailRow.style.display = 'table-row';
      const jobName = btn.dataset.jobName || job.name || 'job';
      btn.setAttribute('aria-expanded', 'true');
      btn.setAttribute('aria-label', `Hide details for job ${jobName}`);
      btn.title = `Hide details for ${jobName}`;
      populateDetailsPanel(job);
    });
  });

  // Edit
  document.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', enterEditMode));

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const id = Number(e.currentTarget.dataset.id);
      const ok = await showConfirm('Are you sure you want to DELETE this job? This cannot be undone.');
      if (!ok) return;

      jobs = jobs.filter(j => j.id !== id);
      await saveJobs();
      renderTable();
    });
  });
  // Add material in details row
  document.querySelectorAll('.add-material-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      const id     = Number(e.currentTarget.dataset.id);
      const detRow = document.getElementById(`details-${id}`);
      const matTbody = detRow.querySelector('.materials-table tbody');
      if (!matTbody) return;
      addEmptyMaterialRow(matTbody);
    });
  });

  // Save details (in-row button)
  document.querySelectorAll('.save-details-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const id     = Number(e.currentTarget.dataset.id);
      const detRow = document.getElementById(`details-${id}`);
      const idx    = jobs.findIndex(j => j.id === id);
      if (idx < 0 || !detRow) return;
      const mats = Array.from(detRow.querySelectorAll('.materials-table tbody tr')).map(row => {
        const type = row.querySelector('[data-field="type"]').value;
        const name = row.querySelector('[data-field="name"]').value;
        const qty = Number(row.querySelector('[data-field="qty"]').value) || 0;
        const unitPrice = Number(row.querySelector('[data-field="unitPrice"]').value) || 0;
        const matStatus = row.querySelector('[data-field="matStatus"]').value;
        const totalCost = +(qty * unitPrice).toFixed(2);
        return { type, name, qty, unitPrice, matStatus, totalCost };
      }).filter(m => m.name || m.qty || m.unitPrice);

      const walls = Number(detRow.querySelector('[data-field="sqftWalls"]').value) || 0;
      const floors = Number(detRow.querySelector('[data-field="sqftFloors"]').value) || 0;
      Object.assign(jobs[idx], {
        materials:  mats,
        sqftWalls:  walls,
        sqftFloors: floors,
        sqftTotal:  walls + floors
      });
      await saveJobs();
      renderTable();
    });
  });
}

// Upload files
document.getElementById('fileUploadForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();

  const input = e.target.querySelector('input[type="file"]');
  const file = input.files[0];
  if (!file || !currentJobId) return alert("Missing file or job ID");

  const formData = new FormData();
  formData.append('file', file);
  formData.append('job_id', currentJobId);

  const res = await fetch('/api/jobs.php', { method: 'POST', body: formData });
  const result = await res.json();

  if (result.status === 'ok') {
    input.value = '';
    document.getElementById('uploadedPreview').innerHTML = `
      <p>File uploaded ✔️</p>
      ${file.type.startsWith('image/')
        ? `<img src="/uploads/job_files/${result.path || file.name}" style="max-width:200px;margin-top:10px;">`
        : `<a href="/uploads/job_files/${result.path || file.name}" target="_blank">View File</a>`
      }
    `;
  } else {
    alert('Upload failed: ' + (result.error || 'Unknown error'));
  }
});


// allow adding a blank row in the side-panel
document.getElementById('det-addMat')?.addEventListener('click', () => {
  const matBody = document.getElementById('det-mats');
  if (matBody) addEmptyMaterialRow(matBody);
});

function closeOverlay() {
  if (!panel || !overlay) return;
  panel.classList.remove('visible');
  panel.classList.add('hidden');
  overlay.classList.remove('visible');
  document.querySelectorAll('.details-row').forEach(row => (row.style.display = 'none'));
  document.querySelectorAll('.more-btn').forEach(btn => {
    btn.setAttribute('aria-expanded', 'false');
    const jobName = btn.dataset.jobName;
    if (jobName) {
      btn.setAttribute('aria-label', `View details for job ${jobName}`);
      btn.title = `View details for ${jobName}`;
    } else {
      btn.setAttribute('aria-label', 'View job details');
      btn.removeAttribute('title');
    }
  });
}

if (saveBtn) {
  saveBtn.addEventListener('click', async () => {
    const job = jobs.find(j => j.id == currentJobId);
    if (!job) return;

    const mats = Array.from(document.querySelectorAll('#det-mats tr')).map(row => ({
      type: row.querySelector('select[data-field="type"]').value,
      name: row.querySelector('input[data-field="name"]').value,
      qty: Number(row.querySelector('input[data-field="qty"]').value) || 0,
      unitPrice: Number(row.querySelector('input[data-field="unitPrice"]').value) || 0,
      totalCost: Number(row.querySelector('input[data-field="totalCost"]').value) || 0,
      matStatus: row.querySelector('select[data-field="matStatus"]').value
    })).filter(m => m.name || m.qty || m.unitPrice);
    job.materials = mats;

    job.sqftWalls = Number(document.getElementById('det-walls').value) || 0;
    job.sqftFloors = Number(document.getElementById('det-floors').value) || 0;
    job.sqftTotal = Number(document.getElementById('det-total').value) || 0;
    job.assignee = document.getElementById('det-assignee').value;
    job.contact = document.getElementById('det-contact').value;
    job.notes = document.getElementById('det-notes').value;


// allow adding a blank row in the side-panel
    await saveJobs();
    renderTable();
    closeOverlay();
  });
}

if (closeBtn) closeBtn.addEventListener('click', closeOverlay);
overlay?.addEventListener('click', closeOverlay);

function bindForm() {
      if (!form) return;
  if (isViewer) {
    form.setAttribute('aria-disabled', 'true');
    return;
  }
  form.onsubmit = async e => {
    e.preventDefault();
    const name = jobNameInput.value.trim();
    const gc   = gcNameInput.value.trim();
    const date = dateInput.value;
    const type = typeCheckboxes()
      .filter(cb => cb.checked)
      .map(cb => cb.value)
      .join(', ');

    if (editingId !== null) {
      const job = jobs.find(j => j.id === editingId);
      Object.assign(job, { name, gc, date, type });
      editingId = null;
      submitBtn.textContent = 'Add Job';
    } else {
      const newId = jobs.length ? jobs[jobs.length - 1].id + 1 : 1;
      jobs.push({
        id:        newId,
        name, gc, date, type,
        status:    'Take-off',
        materials: [],
        sqftWalls:  0,
        sqftFloors: 0,
        sqftTotal:  0
      });
    }

    await saveJobs();
    renderTable();
    form.reset();
  };
}
