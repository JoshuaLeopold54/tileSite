document.addEventListener('DOMContentLoaded', init);

const API = '/api/contacts.php';
let contacts = [];
let filtered = [];
let editingId = null;

const form           = document.getElementById('contactForm');
const nameInput      = document.getElementById('contactName');
const companyInput   = document.getElementById('companyName');
const roleInput      = document.getElementById('role');
const emailInput     = document.getElementById('email');
const phoneInput     = document.getElementById('phone');
const submitBtn      = form ? form.querySelector('button[type="submit"]') : null;
const tbody          = document.querySelector('#contactsTable tbody');
const searchInput    = document.getElementById('contactSearch');
let currentSort      = { field: null, asc: true };

async function init() {
  await loadContacts();
  filtered = contacts.slice();
  renderTable();
  bindForm();
  bindSearch();

  if (window.USER_ROLE === 'viewer' && form) {
    form.style.display = 'none';
  }
}

async function loadContacts() {
  try {
    const res = await fetch(API);
    if (res.status === 401) {
      window.location.href = '/login.php';
      return;
    }
    if (!res.ok) {
      console.error(`Unexpected ${res.status} from ${API}:`, await res.text());
      contacts = [];
      return;
    }
    contacts = await res.json().catch(() => []);
  } catch (err) {
    console.error('Network error in loadContacts():', err);
    contacts = [];
  }
}

async function saveContacts() {
  try {
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contacts)
    });
    if (!res.ok) {
      const txt = await res.text();
      console.error(`❌ contacts POST ${res.status}:`, txt);
      alert(`Error saving contacts: ${res.status} — see console for details`);
    }
  } catch (err) {
    console.error('Network error in saveContacts():', err);
    alert('Network error – could not save contacts');
  }
}

function showConfirm(message) {
  return new Promise(resolve => {
    const modal  = document.getElementById('confirmModal');
    const msgEl  = document.getElementById('confirmMessage');
    const btnOk  = document.getElementById('confirmOk');
    const btnNo  = document.getElementById('confirmCancel');

    msgEl.textContent = message;
    modal.classList.remove('hidden');

    function cleanup(answer) {
      modal.classList.add('hidden');
      btnOk.removeEventListener('click', onOk);
      btnNo.removeEventListener('click', onNo);
      resolve(answer);
    }
    function onOk() { cleanup(true); }
    function onNo() { cleanup(false); }

    btnOk.addEventListener('click', onOk);
    btnNo.addEventListener('click', onNo);
  });
}

function renderTable() {
  tbody.innerHTML = '';

  if (!filtered.length) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td colspan="8" class="no-data">No contacts found.</td>`;
    tbody.appendChild(tr);
    return;
  }

  filtered.forEach(contact => {
    const tr = document.createElement('tr');

    const tdEdit = document.createElement('td');
    if (window.USER_ROLE !== 'viewer') {
      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.classList.add('btn','btn-secondary','edit-btn');
      editBtn.dataset.id = contact.id;
      editBtn.textContent = '✎';
      tdEdit.appendChild(editBtn);
    }
    tr.appendChild(tdEdit);

    ['name','company','role','email','phone'].forEach(field => {
      const td = document.createElement('td');
      td.textContent = contact[field] || '';
      tr.appendChild(td);
    });

    const tdDel = document.createElement('td');
    if (window.USER_ROLE !== 'viewer') {
      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.classList.add('btn','btn-danger','delete-btn');
      delBtn.dataset.id = contact.id;
      delBtn.textContent = '🗑';
      tdDel.appendChild(delBtn);
    }
    tr.appendChild(tdDel);

    tbody.appendChild(tr);
  });

  bindSorting();
  bindRowButtons();
}

function bindSearch() {
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim().toLowerCase();
    if (!q) {
      filtered = contacts.slice();
    } else {
      filtered = contacts.filter(c =>
        c.name.toLowerCase().includes(q)    ||
        c.company.toLowerCase().includes(q) ||
        (c.role || '').toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q)   ||
        (c.phone || '').toLowerCase().includes(q)
      );
    }
    renderTable();
  });
}

if (phoneInput) {
  phoneInput.addEventListener('input', formatPhone);

  function formatPhone(e) {
    let digits = e.target.value.replace(/\D/g, '').slice(0,10);
    let formatted = digits;

    if (digits.length > 6) {
      formatted = digits.slice(0,3) + '-' + digits.slice(3,6) + '-' + digits.slice(6);
    } else if (digits.length > 3) {
      formatted = digits.slice(0,3) + '-' + digits.slice(3);
    }

    e.target.value = formatted;
  }
}

function bindSorting() {
  document.querySelectorAll('#contactsTable thead th.sortable')
    .forEach(th => {
      th.onclick = () => {
        const field = th.dataset.sort;
        if (currentSort.field === field) {
          currentSort.asc = !currentSort.asc;
        } else {
          currentSort.field = field;
          currentSort.asc = true;
        }
        document.querySelectorAll('th.sortable')
          .forEach(h => h.classList.remove('asc','desc'));
        th.classList.add(currentSort.asc ? 'asc' : 'desc');

        contacts.sort((a, b) => {
          let vA = a[field], vB = b[field];
          return currentSort.asc
            ? String(vA).localeCompare(String(vB))
            : String(vB).localeCompare(String(vA));
        });

        renderTable();
      };
    });
}

function bindRowButtons() {
  if (window.USER_ROLE === 'viewer') return;

  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', enterEditMode);
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      const id = Number(e.currentTarget.dataset.id);
      const ok = await showConfirm('Are you sure you want to DELETE this contact? This cannot be undone.');
      if (!ok) return;
      contacts = contacts.filter(c => c.id !== id);
      await saveContacts();
      filtered = contacts.slice();
      renderTable();
    });
  });
}

function enterEditMode(e) {
  const id = Number(e.currentTarget.dataset.id);
  const contact = contacts.find(c => c.id === id);
  if (!contact) return;

  nameInput.value    = contact.name;
  companyInput.value = contact.company;
  roleInput.value    = contact.role || '';
  emailInput.value   = contact.email || '';
  phoneInput.value   = contact.phone || '';

  editingId = id;
  submitBtn.textContent = 'Update Contact';
  form.scrollIntoView({ behavior: 'smooth' });
}

function bindForm() {
  if (window.USER_ROLE === 'viewer') return;
  form.onsubmit = async e => {
    e.preventDefault();
    const name    = nameInput.value.trim();
    const company = companyInput.value.trim();
    const role    = roleInput.value.trim();
    const email   = emailInput.value.trim();
    const phone   = phoneInput.value.trim();

    if (editingId !== null) {
      const idx = contacts.findIndex(c => c.id === editingId);
      if (idx >= 0) {
        Object.assign(contacts[idx], { name, company, role, email, phone });
      }
      editingId = null;
      submitBtn.textContent = 'Add Contact';
    } else {
      const newId = contacts.length
        ? contacts[contacts.length - 1].id + 1
        : 1;
      contacts.push({ id: newId, name, company, role, email, phone });
    }

    await saveContacts();
    filtered = contacts.slice();
    renderTable();
    form.reset();
  };
}
