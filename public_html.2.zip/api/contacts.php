<?php
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$role = $_SESSION['role'] ?? 'viewer';

// DB Connection
require __DIR__ . '/db.php'; // defines $pdo

header('Content-Type: application/json; charset=utf-8');

switch ($_SERVER['REQUEST_METHOD']) {
    case 'PUT':
    case 'DELETE':
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        break;

    case 'GET':
        try {
            $stmt = $pdo->query('SELECT id, name, company, role, email, phone
                                 FROM contacts
                                 ORDER BY id ASC');
            $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($contacts);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
        }
        break;

    case 'POST':
        // Only allow admins and editors to modify contacts
        if (!in_array($role, ['admin', 'editor'], true)) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden – read-only access']);
            exit;
        }

        $payload = json_decode(file_get_contents('php://input'), true);
        if (!is_array($payload)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid JSON payload']);
            exit;
        }

        $ids = [];
        foreach ($payload as $contact) {
            if (
                !isset($contact['id'], $contact['name'], $contact['company'], $contact['email']) ||
                (!is_int($contact['id']) && !ctype_digit($contact['id'])) ||
                !filter_var($contact['email'], FILTER_VALIDATE_EMAIL)
            ) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid or missing fields in one of the contacts']);
                exit;
            }
            $ids[] = (int)$contact['id'];
        }

        try {
            $pdo->beginTransaction();

            $sql = "
                INSERT INTO contacts
                    (id, name, company, role, email, phone)
                VALUES
                    (:id, :name, :company, :role, :email, :phone)
                ON DUPLICATE KEY UPDATE
                    name    = VALUES(name),
                    company = VALUES(company),
                    role    = VALUES(role),
                    email   = VALUES(email),
                    phone   = VALUES(phone)
            ";
            $upsert = $pdo->prepare($sql);

            foreach ($payload as $contact) {
                $upsert->execute([
                    ':id'      => (int)$contact['id'],
                    ':name'    => $contact['name'],
                    ':company' => $contact['company'],
                    ':role'    => $contact['role'] ?? '',
                    ':email'   => $contact['email'],
                    ':phone'   => $contact['phone'] ?? ''
                ]);
            }

            if (count($ids)) {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $delStmt = $pdo->prepare("DELETE FROM contacts WHERE id NOT IN ($placeholders)");
                foreach ($ids as $i => $cid) {
                    $delStmt->bindValue($i + 1, $cid, PDO::PARAM_INT);
                }
                $delStmt->execute();
            } else {
                $pdo->exec('TRUNCATE TABLE contacts');
            }

            $pdo->commit();
            echo json_encode(['status' => 'ok']);
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
