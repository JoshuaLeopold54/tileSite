<?php
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}
$role = $_SESSION['role'] ?? 'viewer';

// 1) DB Connection
require __DIR__ . '/db.php';  // defines $pdo

// Always JSON from here
header('Content-Type: application/json; charset=utf-8');

// Handle file upload if it's a multipart POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && isset($_POST['job_id'])) {
  $jobId = (int) $_POST['job_id'];
  $file = $_FILES['file'];

  $uploadDir = __DIR__ . '/../uploads/job_files/';
  if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

  $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
  $name = uniqid("jobfile_", true) . '.' . $ext;
  $path = $uploadDir . $name;

  if (move_uploaded_file($file['tmp_name'], $path)) {
    $stmt = $pdo->prepare("UPDATE jobs SET file_path = ? WHERE id = ?");
    $stmt->execute([$name, $jobId]);
    echo json_encode(['status' => 'ok']);
  } else {
    http_response_code(500);
    echo json_encode(['error' => 'File upload failed']);
  }
  exit;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            $stmt = $pdo->query('SELECT * FROM jobs ORDER BY id ASC');
            $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($jobs);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
        }
        break;

    case 'POST':
        if (!in_array($role, ['editor', 'admin'], true)) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden – read-only access']);
            exit;
        }

        $payload = json_decode(file_get_contents('php://input'), true);
        if (!is_array($payload)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid JSON payload']);
            exit;
        }

        // Validate each job
        $ids = [];
        foreach ($payload as $job) {
            if (
                !isset($job['id'], $job['name'], $job['gc'], $job['date'], $job['status'])
                || (!is_int($job['id']) && !ctype_digit($job['id']))
                || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $job['date'])
            ) {
                http_response_code(400);
                echo json_encode(['error' => "Invalid or missing fields in one of the jobs"]);
                exit;
            }
            $ids[] = (int)$job['id'];
        }

        try {
            $pdo->beginTransaction();

            $sql = "
                INSERT INTO jobs
                    (id, name, gc, date, type, status, materials, sqftWalls, sqftFloors, sqftTotal, assignee, contact, notes)
                VALUES
                    (:id, :name, :gc, :date, :type, :status, :materials, :sqftWalls, :sqftFloors, :sqftTotal, :assignee, :contact, :notes)
                ON DUPLICATE KEY UPDATE
                    name       = VALUES(name),
                    gc         = VALUES(gc),
                    date       = VALUES(date),
                    type       = VALUES(type),
                    status     = VALUES(status),
                    materials  = VALUES(materials),
                    sqftWalls  = VALUES(sqftWalls),
                    sqftFloors = VALUES(sqftFloors),
                    sqftTotal  = VALUES(sqftTotal),
                    assignee   = VALUES(assignee),
                    contact    = VALUES(contact),
                    notes      = VALUES(notes)
            ";
            $upsert = $pdo->prepare($sql);

            foreach ($payload as $job) {
                $materials = json_encode($job['materials'] ?? []);
                $upsert->execute([
                    ':id'         => (int)$job['id'],
                    ':name'       => $job['name'],
                    ':gc'         => $job['gc'],
                    ':date'       => $job['date'],
                    ':type'       => $job['type'] ?? '',
                    ':status'     => $job['status'],
                    ':materials'  => $materials,
                    ':sqftWalls'  => (int)($job['sqftWalls'] ?? 0),
                    ':sqftFloors' => (int)($job['sqftFloors'] ?? 0),
                    ':sqftTotal'  => (int)($job['sqftTotal'] ?? 0),
                    ':assignee'   => $job['assignee'] ?? '',
                    ':contact'    => $job['contact']  ?? '',
                    ':notes'      => $job['notes']    ?? ''
                ]);
            }

            // Delete rows not present in the payload
            if (count($ids)) {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $delStmt = $pdo->prepare("DELETE FROM jobs WHERE id NOT IN ($placeholders)");
                foreach ($ids as $i => $jid) {
                    $delStmt->bindValue($i + 1, $jid, PDO::PARAM_INT);
                }
                $delStmt->execute();
            } else {
                $pdo->exec('TRUNCATE TABLE jobs');
            }

            $pdo->commit();
            echo json_encode(['status' => 'ok']);

        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'DB Error: ' . $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
