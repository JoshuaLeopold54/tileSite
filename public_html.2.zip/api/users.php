<?php
session_start();
ini_set('display_errors',1);
error_reporting(E_ALL);

if (!isset($_SESSION['user'])) {
  http_response_code(401);
  echo json_encode(['error'=>'Not authenticated']);
  exit;
}
$role = $_SESSION['role'] ?? 'viewer';

require __DIR__ . '/db.php';
if (!isset($pdo)) {
  http_response_code(500);
  echo json_encode(['error'=>'Could not connect to database']);
  exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
  switch ($_SERVER['REQUEST_METHOD']) {
    // ─── FETCH ALL USERS ───
case 'GET':
  // Allow all roles to view users, but restrict fields if needed
    $stmt = $pdo->query("
      SELECT
        id,
        username,
        first_name,
        last_name,
        email,
        role
      FROM users
      ORDER BY first_name, last_name
    ");
  echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
  break;

    // ─── CREATE NEW USER ───
    case 'POST':
      if ($role!=='admin') {
        http_response_code(403);
        echo json_encode(['error'=>'Insufficient permissions']);
        exit;
      }
      $in = json_decode(file_get_contents('php://input'), true);
      if (!isset($in['username'], $in['password'])) {
        http_response_code(400);
        echo json_encode(['error'=>'username & password required']);
        exit;
      }
      try {
        $hash = password_hash($in['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
          INSERT INTO users
            (username,password,first_name,last_name,email,phone,position,department,role,avatar_url)
          VALUES
            (:username,:hash,:first_name,:last_name,:email,:phone,:position,:department,:role,:avatar_url)
        ");
        $stmt->execute([
          ':username'   => $in['username'],
          ':hash'       => $hash,
          ':first_name' => $in['first_name'] ?? null,
          ':last_name'  => $in['last_name']  ?? null,
          ':email'      => $in['email']      ?? null,
          ':phone'      => $in['phone']      ?? null,
          ':position'   => $in['position']   ?? null,
          ':department' => $in['department'] ?? null,
          ':role'       => $in['role']       ?? 'viewer',
          ':avatar_url' => $in['avatar_url'] ?? null
        ]);
        echo json_encode(['status'=>'ok','id'=>$pdo->lastInsertId()]);
      } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
          'error'   => 'Database error',
          'message' => $e->getMessage()
        ]);
      }
      break;

    // ─── UPDATE EXISTING USER ───
    case 'PUT':
      if ($role !== 'admin') {
        http_response_code(403);
        echo json_encode(['error'=>'Insufficient permissions']);
        exit;
      }
      $in = json_decode(file_get_contents('php://input'), true) ?: [];
      if (empty($in['id'])) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing user id']);
        exit;
      }
      // build dynamic SET clauses
      $sets   = [];
      $params = [':id'=> (int)$in['id']];
      foreach (['first_name','last_name','email','phone','position','department','role','avatar_url'] as $f) {
        if (isset($in[$f])) {
          $sets[]       = "`$f` = :$f";
          $params[":$f"] = $in[$f];
        }
      }
      if (!empty($in['password'])) {
        $sets[]         = "password = :hash";
        $params[':hash'] = password_hash($in['password'], PASSWORD_DEFAULT);
      }
      if ($sets) {
        $sql = "UPDATE users SET ".implode(',', $sets)." WHERE id=:id";
        $pdo->prepare($sql)->execute($params);
      }
      echo json_encode(['status'=>'ok']);
      break;

    // ─── DELETE USER ───
    case 'DELETE':
      if ($role !== 'admin') {
        http_response_code(403);
        echo json_encode(['error'=>'Insufficient permissions']);
        exit;
      }
      $id = (int)($_GET['id'] ?? 0);
      if ($id < 1) {
        http_response_code(400);
        echo json_encode(['error'=>'Missing or invalid user id']);
        exit;
      }
      $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
      $stmt->execute([$id]);
      if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['error'=>'User not found']);
      } else {
        echo json_encode(['status'=>'ok']);
      }
      break;

    default:
      http_response_code(405);
      echo json_encode(['error'=>'Method not allowed']);
  }
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['error'=>'Database error','message'=>$e->getMessage()]);
}
