<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user'])) {
  http_response_code(401);
  exit(json_encode(['error'=>'Not authenticated']));
}

require __DIR__ . '/db.php';

$stmt = $pdo->prepare('SELECT id FROM users WHERE username = :uname');
$stmt->execute([':uname'=> $_SESSION['user']]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) {
  http_response_code(401);
  exit(json_encode(['error'=>'Invalid session user']));
}
$userId = (int)$row['id'];

switch ($_SERVER['REQUEST_METHOD']) {
  case 'GET':
    $stmt = $pdo->prepare("
      SELECT first_name, last_name, email, phone, position, department, avatar_url
      FROM users
      WHERE id = :id
    ");
    $stmt->execute([':id'=>$userId]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    echo json_encode($profile);
    break;

  case 'POST':
    $input  = json_decode(file_get_contents('php://input'), true);
    // Only allow updating these fields:
    $fields = ['email', 'phone', 'department', 'avatar_url'];
    $sets   = [];
    $params = [':id'=>$userId];

    foreach ($fields as $f) {
      if (array_key_exists($f, $input)) {
        $sets[] = "`$f` = :$f";
        $params[":$f"] = $input[$f];
      }
    }

    if ($sets) {
      $sql = "UPDATE users SET " . implode(',', $sets) . " WHERE id = :id";
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);
    }

    echo json_encode(['status'=>'ok']);
    break;

  default:
    http_response_code(405);
    echo json_encode(['error'=>'Method not allowed']);
    break;
}
