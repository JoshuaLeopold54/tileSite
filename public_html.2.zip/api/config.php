<?php
header('Content-Type: application/json; charset=utf-8');
  
$host   = 'localhost';
$dbname = 'u430387261_LeesJobs';
$user   = 'u430387261_LeesJobsAdmin';
$pass   = 'PurpleBears8090**';
$charset= 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['error'=>"DB Connection failed: {$e->getMessage()}"]);
  exit;
}
