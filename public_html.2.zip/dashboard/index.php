<?php
session_start();
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit;
}
$role = $_SESSION['role'] ?? 'viewer';

// 1) Require login
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit;
}

// 2) Connect to DB
require __DIR__ . '/../api/db.php';

// 3) Fetch the logged-in user’s row
$stmt = $pdo->prepare("
  SELECT id, username, first_name, last_name,
         email, phone, position, department, avatar_url
  FROM users
  WHERE username = :uname
  LIMIT 1
");
$stmt->execute([':uname' => $_SESSION['user']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
  // no such user? force logout
  session_destroy();
  header('Location: /login.php');
  exit;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <title>Lee’s Ceramics – Dashboard</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?=htmlspecialchars($role,ENT_QUOTES)?>">
  <?php include __DIR__ . '/../_partials/navbar.php'; ?>

<main class="container">

  <section class="card">
    <h2>Welcome back, <?=htmlspecialchars($user['first_name'],ENT_QUOTES)?>!</h2>
    <p>Use the menu or quick links below to jump straight into your work.</p>
  </section>

  <section class="card admin-grid">
    <?php if ($role === 'admin'): ?>
      <h3>Admin Features</h3>
      <div class="grid">
        <a href="/users" class="dash-card">
          <i class="fas fa-user-plus"></i>
          <span>Create New User</span>
        </a>
        <a href="/users" class="dash-card">
          <i class="fas fa-users"></i>
          <span>Manage Users</span>
        </a>
    <?php else: ?>
      <div class="dashboard-links">
    <?php endif; ?>
        <a href="/contacts" class="dash-card"><i class="fas fa-address-book"></i> Contacts</a>
        <a href="/" class="dash-card"><i class="fas fa-briefcase"></i> Jobs</a>
        <a href="/reports" class="dash-card"><i class="fas fa-chart-line"></i> Reports</a>
        <a href="/profile/settings.php" class="dash-card"><i class="fas fa-cog"></i> Profile Settings</a>
      </div>
  </section>

</main>
</body>
</html>
