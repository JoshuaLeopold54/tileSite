<?php
// Adjust the path if needed to point at your PDO config:
require __DIR__ . '/api/db.php';

// 1) Your new password:
$newPassword = 'password1';

// 2) Generate a bcrypt hash:
$hash = password_hash($newPassword, PASSWORD_DEFAULT);

// 3) Update the admin user in the database:
$stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
$stmt->execute([$hash]);

echo "✅ Admin password reset. New password is: {$newPassword}\n";