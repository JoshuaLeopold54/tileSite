<?php
  session_start();
  if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location:/login.php');
    exit;
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Lee’s Ceramics – User Management</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?= htmlspecialchars($_SESSION['role'], ENT_QUOTES) ?>">
  <?php include __DIR__ . '/../_partials/navbar.php'; ?>

  <main>
    <!-- ─── Create User Card ─── -->
    <section class="card user-card">
      <h2>Create New User</h2>
      <form id="userForm">
        <div class="form-grid">
          <div class="form-group">
            <label for="username">Username <span class="required">*</span></label>
            <input type="text" id="username"    name="username"   required>
          </div>
          <div class="form-group">
            <label for="password">Password <span class="required">*</span></label>
            <input type="password" id="password" name="password"   required>
          </div>
          <div class="form-group">
            <label for="role">Role <span class="required">*</span></label>
            <select id="role" name="role" required>
              <option value="viewer">Viewer</option>
              <option value="editor">Editor</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" id="first_name" name="first_name">
          </div>
          <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" id="last_name"  name="last_name">
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email"     name="email">
          </div>
          <div class="form-group">
            <label for="phone">Phone</label>
            <input type="tel" id="phone"       name="phone">
          </div>
          <div class="form-group">
            <label for="position">Position</label>
            <select name="position" id="position" required>
              <option value="">-- Select Position --</option>
              <option value="Project Manager">Project Manager</option>
              <option value="Foreman">Foreman</option>
              <option value="Tile Setter">Tile Setter</option>
              <option value="Tile Grouter">Tile Grouter</option>
              <option value="Laborer">Laborer</option>
              <option value="Truck Driver">Truck Driver</option>
            </select>
          </div>
          <div class="form-group">
            <label for="department">Department</label>
            <input type="text" id="department" name="department">
          </div>
          <div class="form-group full-width">
            <label for="avatar_url">Avatar URL</label>
            <input type="url" id="avatar_url"  name="avatar_url" placeholder="https://…">
          </div>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary">➕ Create New User</button>
          <button type="reset"  class="btn btn-secondary">Clear</button>
        </div>
      </form>
    </section>

    <!-- ─── Existing Users Table ─── -->
  <section class="card user-card" style="margin-top:1rem;">
    <h2>Existing Users</h2>
    <table id="usersTable">
      <thead>
        <tr>
          <th></th>
          <th>ID</th>
          <th>Username</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <!-- rows injected by js/users.js -->
      </tbody>
    </table>
  </section>
  </main>

  <script src="/js/users.js" defer></script>
</body>
</html>
