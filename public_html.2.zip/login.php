<?php
session_start();
require __DIR__ . '/api/db.php';  // pure PDO config, no headers

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';

  // Fetch user
  $stmt = $pdo->prepare('SELECT username, password, role FROM users WHERE username = ?');
  $stmt->execute([$username]);
  $user = $stmt->fetch();

  if (!$user) {
    $error = 'User not found';
  } elseif (!password_verify($password, $user['password'])) {
    $error = 'Invalid password';
  } else {
    $_SESSION['user'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    header('Location: /dashboard/');
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Admin Login – Lee’s Ceramics</title>
  <!-- use your main stylesheet -->
  <link rel="stylesheet" href="/css/style.css">
</head>
<body class="login-page">
  <div class="login-container">
    <!-- LOGO ABOVE THE CARD -->
    <img src="../images/logo.png"
         alt="Lee’s Ceramics Logo"
         class="login-logo-top">

    <!-- LOGIN CARD -->
    <div class="login-card">
      <div class="brand">Authorized Login</div>

      <?php if ($error): ?>
        <div class="error"><?=htmlspecialchars($error)?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username"
                 required autofocus
                 value="<?=htmlspecialchars($username)?>">
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn-primary">Log In</button>
      </form>
    </div>
  </div>
</body>
</html>
