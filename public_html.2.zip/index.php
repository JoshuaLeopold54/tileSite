<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Lee’s Ceramics Job Tracker</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?= htmlspecialchars($_SESSION['role'], ENT_QUOTES) ?>">

<nav class="navbar">
  <a href="/" class="brand">Lee’s Ceramics</a>
  <ul class="nav-links" id="primaryNav">
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/" class="active">Jobs</a></li>
    <li><a href="/contacts">Contacts</a></li>
    <li><a href="/reports">Reports</a></li>
    <li><a href="/settings" aria-label="Settings"><i class="fas fa-cog" aria-hidden="true"><i class="fas fa-cog"></i></a></li>
  </ul>
  <div class="user-menu">
    <img src="/images/avatar.png" alt="avatar">
    <div class="dropdown">
      <a href="/profile">Profile</a>
      <a href="/logout.php">Logout</a>
    </div>
  </div>
  <button class="hamburger" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primaryNav">☰</button>
</nav>
<main>
  <!-- Add Job Form -->
  <section class="card">
      
    <?php if (($_SESSION['role'] ?? 'viewer') === 'viewer'): ?>
      <div class="note-box" style="text-align: center;">
        <strong>Note:</strong> You have <em>read-only</em> access to the jobs list.<br>
        If you need to make changes, please contact your administrator.
      </div>
    <?php endif; ?>
    
    <form id="jobForm">
      <input type="text"    id="jobName"   name="jobName"   placeholder="Job Name" required>
      <input type="text"    id="gcName"    name="gcName"    placeholder="General Contractor" required>
      <input type="date"    id="startDate" name="startDate" required>

      <fieldset>
        <legend>Type</legend>
        <label><input type="checkbox" name="type" value="Walls"> Walls</label>
        <label><input type="checkbox" name="type" value="Floors"> Floors</label>
        <label><input type="checkbox" name="type" value="Patchwork"> Patchwork</label>
        <label><input type="checkbox" name="type" value="Demolition"> Demolition</label>
      </fieldset>

      <button type="submit">Add Job</button>
    </form>
  </section>
  
    
<div class="search-wrapper">
  <input type="text" id="jobSearch" placeholder="🔍 Search jobs…" class="form-control" />
</div>
  <!-- Jobs Table -->
  <section id="tableSection" class="card">
    <table id="jobsTable">
      <thead>
        <tr>
          <th></th>
          <th data-sort="name"    class="sortable">Job Name</th>
          <th data-sort="gc"      class="sortable">GC Name</th>
          <th data-sort="date"    class="sortable">Start Date</th>
          <th data-sort="type"    class="sortable">Type</th>
          <th data-sort="status"  class="sortable">Status</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <!-- rows injected by js/app.js -->
      </tbody>
    </table>
  </section>
</main>

<script>
  window.USER_ROLE = document.body.dataset.role;

  document.addEventListener('DOMContentLoaded', () => {

    const burger = document.querySelector('.hamburger');
    const navLinks = document.getElementById('primaryNav');
    if (burger && navLinks) {
        const updateAria = () => {
        burger.setAttribute('aria-expanded', navLinks.classList.contains('open') ? 'true' : 'false');
      };
      burger.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        updateAria();
      });
      navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          navLinks.classList.remove('open');
          updateAria();
        });
        updateAria();
      });
    }
  });
</script>

<script src="js/app.js" defer></script>

<!-- job details overlay -->
<div id="detailsOverlay" class="details-overlay"></div>
<div id="detailsPanel" class="details-panel hidden">
  <button id="closeDetails" class="close-btn">×</button>
  <h3></h3>

  <div class="section">
    <h4>Basic Info</h4>
    <p><strong>Job Name:</strong> <span id="det-name"></span></p>
    <p><strong>GC Name:</strong>  <span id="det-gc"></span></p>
    <p><strong>Start Date:</strong> <span id="det-date"></span></p>
    <p><strong>Type:</strong> <span id="det-type"></span></p>
  </div>

  <div class="section">
    <h4>Materials</h4>
    <table class="materials-table">
      <thead><tr>
        <th>Type</th>
        <th>Name</th>
        <th>Qty</th>
        <th>Unit Price</th>
        <th>Total Cost</th>
        <th>Status</th>
        <th></th>
      </tr></thead>
      <tbody id="det-mats"></tbody>
    </table>
    <button id="det-addMat" class="btn">+ Add Material</button>
  </div>
  
    <div class="section">
      <h4>Attach File</h4>
      <form id="fileUploadForm">
        <input type="file" name="file" accept=".pdf,image/*" required>
        <button type="submit">Upload</button>
      </form>
      <div id="uploadedPreview" style="margin-top:10px;"></div>
    </div>

  <div class="section">
    <h4>Square Footage</h4>
    <div class="sqft-row">
      <label>Walls: <input id="det-walls" type="number"/></label>
      <label>Floors: <input id="det-floors" type="number"/></label>
      <label>Total:  <input id="det-total" readonly/></label>
    </div>
  </div>

  <div class="section">
    <h4>Assignment & Notes</h4>
    <label><strong>Assigned To:</strong><br/>
      <select id="det-assignee"></select>
    </label>
    <label><strong>Contact:</strong><br/>
      <input id="det-contact" type="text" placeholder="Email or Phone"/>
    </label>
    <label><strong>Notes:</strong><br/>
      <textarea id="det-notes" rows="4" placeholder="Any extra details…"></textarea>
    </label>
  </div>

  <button id="det-save" class="btn btn-primary">Save Details</button>
</div>

<!-- Confirm Modal -->
<div id="confirmModal" class="modal hidden">
  <div class="modal-overlay"></div>
  <div class="modal-content">
    <p id="confirmMessage">Are you sure?</p>
    <div class="modal-buttons">
      <button id="confirmCancel" class="btn">Cancel</button>
      <button id="confirmOk"     class="btn btn-danger">Delete</button>
    </div>
  </div>
</div>

</body>
</html>
