<!-- _partials/navbar.php -->
<nav class="navbar">
  <a href="/" class="brand">Lee’s Ceramics</a>
  <ul class="nav-links">
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/">Jobs</a></li>
    <li><a href="/contacts">Contacts</a></li>
    <li><a href="/reports">Reports</a></li>
  </ul>
  <div class="user-menu">
    <img src="/images/avatar.png" alt="avatar">
    <div class="dropdown">
      <a href="/profile">Profile</a>
      <a href="/logout.php">Logout</a>
    </div>
  </div>
  <button class="hamburger">☰</button>
</nav>