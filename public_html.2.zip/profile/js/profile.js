document.addEventListener('DOMContentLoaded', init);

const API = '/api/profile.php';
const form = document.getElementById('profileForm');
const editableFields = ['email', 'phone', 'department', 'avatar_url'];
const allFields = [
  'first_name', 'last_name', 'email', 'phone', 'position', 'department', 'avatar_url'
];

async function init() {
  await loadProfile();

  if (form) {
    form.addEventListener('submit', onSave);
  }

  const phoneInput = document.getElementById('phone');
  if (phoneInput) {
    phoneInput.addEventListener('input', () => {
      let digits = phoneInput.value.replace(/\D/g, '').slice(0, 10);
      let formatted = digits;
      if (digits.length > 6) {
        formatted = `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
      } else if (digits.length > 3) {
        formatted = `${digits.slice(0, 3)}-${digits.slice(3)}`;
      }
      phoneInput.value = formatted;
    });

    phoneInput.addEventListener('keypress', e => {
      if (!/\d/.test(e.key) || phoneInput.value.replace(/\D/g, '').length >= 10) {
        e.preventDefault();
      }
    });
  }

  const editBtn = document.getElementById('editProfileBtn');
  if (editBtn) {
    editBtn.addEventListener('click', () => {
      document.querySelector('.profile-card')?.classList.add('hidden');
      document.querySelector('.profile-form-card')?.classList.remove('hidden');
    });
  }
}

async function loadProfile() {
  const res = await fetch(API);
  if (res.status === 401) return window.location = '/login.php';

  const data = await res.json();
  allFields.forEach(f => {
    const el = document.querySelector(`[name="${f}"]`);
    if (el && data[f] != null) {
      el.value = data[f];
      if (!editableFields.includes(f)) {
        el.setAttribute('readonly', true);
        el.classList.add('readonly-field');
        if (el.tagName === 'SELECT' || el.tagName === 'INPUT') {
          el.setAttribute('disabled', true);
        }
      }
    }
  });
}

async function onSave(e) {
  e.preventDefault();
  const payload = {};
  editableFields.forEach(f => {
    const el = document.querySelector(`[name="${f}"]`);
    if (el) {
      payload[f] = el.value.trim();
    }
  });

  const res = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (res.ok) {
    alert('Profile updated!');
    window.location = 'index.php';
  } else {
    const err = await res.text();
    alert('Error saving: ' + err);
  }
}