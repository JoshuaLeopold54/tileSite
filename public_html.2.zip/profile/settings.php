<?php
session_start();
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit;
}

require __DIR__ . '/../api/db.php';
$stmt = $pdo->prepare('SELECT * FROM users WHERE username = :uname');
$stmt->execute([':uname' => $_SESSION['user']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
  session_destroy();
  header('Location: /login.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Edit Profile • Lee’s Ceramics</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?=htmlspecialchars($_SESSION['role'])?>">

<?php include __DIR__ . '/../_partials/navbar.php'; ?>

<main>
  <section class="card">
    <h2>Edit Profile</h2>
    <a href="index.php" class="btn">← Back to Profile</a>
    <form id="profileForm">
      <div class="form-group">
        <label for="firstName">First Name</label>
        <input id="firstName" name="first_name" type="text" value="<?=htmlspecialchars($user['first_name'])?>" readonly>
      </div>
      <div class="form-group">
        <label for="lastName">Last Name</label>
        <input id="lastName" name="last_name" type="text" value="<?=htmlspecialchars($user['last_name'])?>" readonly>
      </div>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input id="email" name="email" type="email" value="<?=htmlspecialchars($user['email'])?>" required>
      </div>
      <div class="form-group">
        <label for="phone">Phone Number</label>
        <input id="phone" name="phone" type="tel" value="<?=htmlspecialchars($user['phone'])?>">
      </div>
      <div class="form-group">
        <label for="position">Position</label>
        <input id="position" name="position" type="text" value="<?=htmlspecialchars($user['position'])?>" readonly>
      </div>
      <div class="form-group">
          <label for=""></label>
      </div>
      <div class="form-group">
          <label for=""></label>
      </div>
      <button type="submit" class="btn btn-primary full-width">Save Changes</button>
    </form>
  </section>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const phoneInput = document.getElementById('phone');
  if (!phoneInput) return;

  phoneInput.addEventListener('input', () => {
    let digits = phoneInput.value.replace(/\D/g, '').slice(0, 10);
    let formatted = digits;
    if (digits.length > 6) {
      formatted = `${digits.slice(0,3)}-${digits.slice(3,6)}-${digits.slice(6)}`;
    } else if (digits.length > 3) {
      formatted = `${digits.slice(0,3)}-${digits.slice(3)}`;
    }
    phoneInput.value = formatted;
  });

  phoneInput.addEventListener('keypress', e => {
    if (!/\d/.test(e.key) || phoneInput.value.replace(/\D/g, '').length >= 10) {
      e.preventDefault();
    }
  });
});
</script>
<script src="/profile/js/profile.js" defer></script>
</body>
</html>
