<?php
session_start();
// DEV: show all PHP errors (remove or tone down in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 1) Require login
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit;
}

// 2) Connect to DB
require __DIR__ . '/../api/db.php';

// 3) Fetch the logged-in user’s row
$stmt = $pdo->prepare("
  SELECT id, username, first_name, last_name,
         email, phone, position, department, avatar_url
  FROM users
  WHERE username = :uname
  LIMIT 1
");
$stmt->execute([':uname' => $_SESSION['user']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
  // no such user? force logout
  session_destroy();
  header('Location: /login.php');
  exit;
}

// extract user ID
$userId = (int)$user['id'];

// 4) Fetch only the jobs assigned to this user
$stmt = $pdo->prepare("SELECT * FROM jobs WHERE assignee = :id");
$stmt->execute([':id' => $userId]);
$assigned = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 5) Compute stats
$activeJobs       = count($assigned);
$totalSqft        = array_sum(array_column($assigned, 'sqftTotal'));

$pendingMaterials = 0;
foreach ($assigned as $j) {
  $mats = json_decode($j['materials'], true) ?: [];
  foreach ($mats as $m) {
    if (($m['matStatus'] ?? '') === 'Pending') {
      $pendingMaterials++;
    }
  }
}

// 6) Total contacts count (you could scope this to “created_by = $userId” if you extend your schema)
$contactsCount = (int)$pdo
  ->query('SELECT COUNT(*) FROM contacts')
  ->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Lee’s Ceramics – Profile</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?= htmlspecialchars($_SESSION['role'], ENT_QUOTES) ?>">
  <?php include __DIR__ . '/../_partials/navbar.php'; ?>

  <main>
    <section class="card profile-card">
      <!-- Profile Header -->
      <div class="profile-header">
        <img
          src="<?= htmlspecialchars($user['avatar_url'] ?: '/images/avatar.png') ?>"
          alt="Avatar"
          class="avatar"
        >
        <div class="profile-info">
          <h2>
            <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
          </h2>
          <p><strong>Email:</strong>
            <?= htmlspecialchars($user['email']) ?>
          </p>
          <p><strong>Phone:</strong>
            <?= htmlspecialchars($user['phone']) ?>
          </p>
          <p><strong>Position:</strong>
            <?= htmlspecialchars($user['position']) ?>
          </p>
        </div>
      </div>

      <!-- Stats Grid -->
      <div class="stats-grid">
        <div class="stat">
          <h5>Active Jobs</h5>
          <p><?= $activeJobs ?></p>
        </div>
        <div class="stat">
          <h5>Total Sqft</h5>
          <p><?= number_format($totalSqft) ?></p>
        </div>
        <div class="stat">
          <h5>Materials Pending</h5>
          <p><?= $pendingMaterials ?></p>
        </div>
        <div class="stat">
          <h5>Contacts</h5>
          <p><?= $contactsCount ?></p>
        </div>
      </div>

      <!-- Action Button -->
      <a href="settings.php" class="btn btn-primary">Edit Profile</a>
    </section>
  </main>
</body>
</html>
