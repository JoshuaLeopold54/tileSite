<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
$role = $_SESSION['role'] ?? 'viewer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Lee’s Ceramics – Contacts</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?= htmlspecialchars($role, ENT_QUOTES) ?>">

<nav class="navbar">
  <a href="/" class="brand">Lee’s Ceramics</a>
  <ul class="nav-links">
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="../">Jobs</a></li>
    <li><a href="/contacts" class="active">Contacts</a></li>
    <li><a href="/reports">Reports</a></li>
    <li><a href="/settings"><i class="fas fa-cog"></i></a></li>
  </ul>
  <div class="user-menu">
    <img src="/images/avatar.png" alt="avatar">
    <div class="dropdown">
      <a href="/profile">Profile</a>
      <a href="/logout.php">Logout</a>
    </div>
  </div>
  <button class="hamburger">☰</button>
</nav>

<main>

  <!-- ── Add Contact Form ── -->
  <?php if ($role !== 'viewer'): ?>
  <section class="card">
    <form id="contactForm" class="form-grid">
      <div class="form-group">
        <label for="contactName">Full Name</label>
        <input type="text" id="contactName" name="contactName"
               placeholder="Jane Doe" required>
      </div>
      <div class="form-group">
        <label for="companyName">Company</label>
        <input type="text" id="companyName" name="companyName"
               placeholder="Acme Co." required>
      </div>
      <div class="form-group">
        <label for="role">Role / Relation</label>
        <input type="text" id="role" name="role" placeholder="Supplier">
      </div>
      <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone"
               placeholder="(555) 123-4567" maxlength="12">
      </div>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email"
               placeholder="jane@acme.com" required>
      </div>
      <button type="submit" class="btn btn-primary full-width">
        Add Contact
      </button>
    </form>
  </section>
  <?php else: ?>
  <section class="card" style="text-align: center; padding: 1rem;">
    <strong>Note:</strong> You have <em>read-only</em> access to the contacts list.
    <br>If you need to make changes, please contact your administrator.
  </section>
  <?php endif; ?>

  <!-- ── Contacts Table ── -->
  <div class="card search-card">
    <input
      type="text"
      id="contactSearch"
      placeholder="🔍 Search contacts…"
      autocomplete="off"
    />
  </div>

  <section id="tableSection" class="card">
    <table id="contactsTable">
      <thead>
        <tr>
          <th></th>
          <th data-sort="name"    class="sortable">Name</th>
          <th data-sort="company" class="sortable">Company</th>
          <th data-sort="role"    class="sortable">Role</th>
          <th data-sort="email"   class="sortable">Email</th>
          <th data-sort="phone"   class="sortable">Phone</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <!-- rows injected by js/contacts.js -->
      </tbody>
    </table>
  </section>
</main>

<!-- Role for JS use -->
<script>
  window.USER_ROLE = document.body.dataset.role;
</script>
<script src="../js/contacts.js" defer></script>

<!-- Hamburger Toggle Script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
  const burger   = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  if (burger && navLinks) {
    burger.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
  }
});
</script>

<!-- Confirm Modal -->
<div id="confirmModal" class="modal hidden">
  <div class="modal-overlay"></div>
  <div class="modal-content">
    <p id="confirmMessage">Are you sure?</p>
    <div class="modal-buttons">
      <button id="confirmCancel" class="btn">Cancel</button>
      <button id="confirmOk"     class="btn btn-danger">Delete</button>
    </div>
  </div>
</div>

</body>
</html>
