<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: /login.php');
    exit;
}
$role = $_SESSION['role'] ?? 'viewer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Lee’s Ceramics – Reports</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body data-role="<?= htmlspecialchars($role, ENT_QUOTES) ?>">

<nav class="navbar">
  <a href="/" class="brand">Lee’s Ceramics</a>
  <ul class="nav-links" id="primaryNav">
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/">Jobs</a></li>
    <li><a href="/contacts">Contacts</a></li>
    <li><a href="/reports" class="active">Reports</a></li>
    <li><a href="/settings" aria-label="Settings"><i class="fas fa-cog" aria-hidden="true"><i class="fas fa-cog"></i></a></li>
  </ul>
  <div class="user-menu">
    <img src="/images/avatar.png" alt="avatar">
    <div class="dropdown">
      <a href="/profile">Profile</a>
      <a href="/logout.php">Logout</a>
    </div>
  </div>
  <button class="hamburger" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primaryNav">☰</button>
</nav>

<main class="reports-main">
  <section class="card">
   <header class="card-header">
      <div>
        <h1>Job Pipeline Reports</h1>
        <p class="card-subtitle">Snapshot of bidding activity, material readiness, and overall workload.</p>
      </div>
      <span class="timestamp" id="reportsTimestamp" aria-live="polite"></span>
    </header>
    <div id="reportsError" class="reports-alert" role="alert" aria-live="assertive" hidden></div>
    <div class="metric-grid" aria-live="polite">
      <article class="metric-card">
        <h2>Total Jobs</h2>
        <p class="metric-value" id="metric-total-jobs">–</p>
      </article>
      <article class="metric-card">
        <h2>Bidding Pipeline</h2>
        <p class="metric-value" id="metric-bidding-jobs">–</p>
        <span class="metric-footnote" id="metric-bidding-share"></span>
      </article>
      <article class="metric-card">
        <h2>Materials In Progress</h2>
        <p class="metric-value" id="metric-material-jobs">–</p>
        <span class="metric-footnote" id="metric-material-share"></span>
      </article>
      <article class="metric-card">
        <h2>Total Square Footage</h2>
        <p class="metric-value" id="metric-total-sqft">–</p>
        <span class="metric-footnote" id="metric-average-sqft"></span>
      </article>
      <article class="metric-card">
        <h2>Estimated Material Spend</h2>
        <p class="metric-value" id="metric-material-cost">–</p>
        <span class="metric-footnote" id="metric-material-cost-note"></span>
      </article>
    </div>
  </section>

  <!-- Example Report Cards -->
  <section class="card">
 <header class="card-header">
      <h2>Status Breakdown</h2>
      <p class="card-subtitle">Distribution of active work by project status.</p>
    </header>
    <div class="table-wrapper">
      <table class="reports-table" aria-describedby="statusSummary">
        <thead>
          <tr>
            <th scope="col">Status</th>
            <th scope="col">Jobs</th>
            <th scope="col">Share</th>
            <th scope="col">Total Sq Ft</th>
          </tr>
        </thead>
        <tbody id="statusBreakdownBody">
          <tr><td colspan="4" class="empty-state">Loading…</td></tr>
        </tbody>
      </table>
    </div>
    <p id="statusSummary" class="sr-only">Table showing the number of jobs, share of total jobs, and square footage per status.</p>
  </section>

  <section class="reports-grid">
    <section class="card">
      <header class="card-header">
        <h2>Bidding Queue</h2>
        <p class="card-subtitle">Active estimates and outstanding proposals.</p>
      </header>
      <div class="table-wrapper">
        <table class="reports-table" aria-describedby="biddingSummary">
          <thead>
            <tr>
              <th scope="col">Job</th>
              <th scope="col">GC</th>
              <th scope="col">Bid Due</th>
              <th scope="col">Sq Ft</th>
              <th scope="col">Estimator</th>
            </tr>
          </thead>
          <tbody id="biddingTableBody">
            <tr><td colspan="5" class="empty-state">Loading…</td></tr>
          </tbody>
        </table>
      </div>
      <p id="biddingSummary" class="sr-only">Table of jobs currently in bidding status with their general contractor, due date, square footage, and estimator.</p>
    </section>

    <section class="card">
      <header class="card-header">
        <h2>Material Procurement</h2>
        <p class="card-subtitle">Jobs awaiting or receiving materials.</p>
      </header>
      <div class="table-wrapper">
        <table class="reports-table" aria-describedby="materialsSummary">
          <thead>
            <tr>
              <th scope="col">Job</th>
              <th scope="col">GC</th>
              <th scope="col">Needed By</th>
              <th scope="col">Sq Ft</th>
              <th scope="col">Coordinator</th>
            </tr>
          </thead>
          <tbody id="materialsTableBody">
            <tr><td colspan="5" class="empty-state">Loading…</td></tr>
          </tbody>
        </table>
      </div>
      <p id="materialsSummary" class="sr-only">Table of jobs in materials-related statuses with their general contractor, material need dates, square footage, and coordinators.</p>
    </section>
  </section>

  <section class="reports-grid">
    <section class="card">
      <header class="card-header">
        <h2>Upcoming Kickoffs</h2>
        <p class="card-subtitle">Next five projects scheduled to start.</p>
      </header>
      <ul class="timeline" id="upcomingList" aria-live="polite">
        <li class="empty-state">Loading…</li>
      </ul>
    </section>

    <section class="card">
      <header class="card-header">
        <h2>Top General Contractors</h2>
        <p class="card-subtitle">Partners ranked by current workload.</p>
      </header>
      <div class="table-wrapper">
        <table class="reports-table" aria-describedby="gcSummary">
          <thead>
            <tr>
              <th scope="col">GC</th>
              <th scope="col">Active Jobs</th>
              <th scope="col">Pipeline Sq Ft</th>
            </tr>
          </thead>
          <tbody id="gcTableBody">
            <tr><td colspan="3" class="empty-state">Loading…</td></tr>
          </tbody>
        </table>
      </div>
      <p id="gcSummary" class="sr-only">Table ranking general contractors by active jobs and total square footage.</p>
    </section>

    <section class="card">
      <header class="card-header">
        <h2>Team Workload</h2>
        <p class="card-subtitle">Assignments grouped by estimator or coordinator.</p>
      </header>
      <div class="table-wrapper">
        <table class="reports-table" aria-describedby="teamSummary">
          <thead>
            <tr>
              <th scope="col">Team Member</th>
              <th scope="col">Active Jobs</th>
              <th scope="col">Pipeline Sq Ft</th>
            </tr>
          </thead>
          <tbody id="teamTableBody">
            <tr><td colspan="3" class="empty-state">Loading…</td></tr>
          </tbody>
        </table>
      </div>
      <p id="teamSummary" class="sr-only">Table summarising workload by assigned estimator or coordinator.</p>
    </section>n>
</main>

<script>
window.USER_ROLE = document.body.dataset.role;

  document.addEventListener('DOMContentLoaded', () => {
    const burger = document.querySelector('.hamburger');
    const navLinks = document.getElementById('primaryNav');
    if (burger && navLinks) {
      const updateAria = () => {
        burger.setAttribute('aria-expanded', navLinks.classList.contains('open') ? 'true' : 'false');
      };
      burger.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        updateAria();
      });
      navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          navLinks.classList.remove('open');
          updateAria();
        });
      });
      updateAria();
    }
  });
</script>
<script src="/js/reports.js" defer></script>
</body>
</html>